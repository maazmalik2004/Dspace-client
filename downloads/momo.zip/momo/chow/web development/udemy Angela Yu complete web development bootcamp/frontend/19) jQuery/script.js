$(document).ready(function(){
    $("h1").css("color","red");
});

$(document).keypress(function(event){
    $("h1").text(event.key);
});

/*
$("button").click(function(event){
    $("h1").slideToggle();
});
*/

$("button").click(function(event){
    $("h1").animate({opacity:0.5}).animate({margin:20}).slideUp().slideDown();
});

//$("h1").before("<button>newbuttonhere</button>");
//$("h1").after("<button>newbuttonhere</button>");

function saveInput() {
    // Get the input element by its ID
    var userInputElement = document.getElementById("userInput");

    // Retrieve the value from the input element
    var userInput = userInputElement.value;

    // Display the user input
    console.log("User input:", userInput);
}
