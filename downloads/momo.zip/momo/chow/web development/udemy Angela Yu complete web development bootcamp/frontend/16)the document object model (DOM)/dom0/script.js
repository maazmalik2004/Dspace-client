alert("hebhenlow");
document.querySelector("h1").innerHTML="good bye"; 