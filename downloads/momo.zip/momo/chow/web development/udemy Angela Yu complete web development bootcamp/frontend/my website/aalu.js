document.getElementById('content').addEventListener('click', function() {
    var sidebar = document.getElementById('sidebar');
    var isCollapsed = sidebar.style.flex === '0 0 1px';

    if (isCollapsed) {
        sidebar.style.flex = '0 0 200px';
    } else {
        sidebar.style.flex = '0 0 1px';
    }
});
