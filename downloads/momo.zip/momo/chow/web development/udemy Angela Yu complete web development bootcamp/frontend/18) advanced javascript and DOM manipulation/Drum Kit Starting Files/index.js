//detecting click press
var numofbutton=7;

for(var i=0;i<numofbutton;i++)
{
    document.querySelectorAll(".drum")[i].addEventListener("click",function(){//anonymous functions
    
    //alert("ola !");
    
    console.log(this);
    console.log(this.innerHTML);
    console.log(this.style.color="green");

    switch(this.innerHTML)
    {
        case "w":var sound1=new Audio("sounds/tom-1.mp3");//creating an audio object
        break;

        case "a":var sound=new Audio("sounds/tom-2.mp3");//creating an audio object
        break;

        case "s":var sound=new Audio("sounds/tom-3.mp3");//creating an audio object
        break;

        case "d":var sound=new Audio("sounds/tom-4.mp3");//creating an audio object
        break;

        case "j":var sound=new Audio("sounds/crash.mp3");//creating an audio object
        break;

        case "k":var sound=new Audio("sounds/snare.mp3");//creating an audio object
        break;

        case "l":var sound=new Audio("sounds/kick-bass.mp3");//creating an audio object
        break;
    }
    sound.play();
    
    buttonanimation(this.innerHTML);
});
}

    //detecting keyboard key press
    document.addEventListener("keydown", function(event) {
        console.log(event.key);
        playsound(event.key);
        buttonanimation(event.key);
    });
    
    function playsound(key) {
        var sound; // Declare the sound variable outside the switch statement
    
        switch (key) {
            case "w":
                sound = new Audio("sounds/tom-1.mp3");
                break;
    
            case "a":
                sound = new Audio("sounds/tom-2.mp3");
                break;
    
            case "s":
                sound = new Audio("sounds/tom-3.mp3");
                break;
    
            case "d":
                sound = new Audio("sounds/tom-4.mp3");
                break;
    
            case "j":
                sound = new Audio("sounds/crash.mp3");
                break;
    
            case "k":
                sound = new Audio("sounds/snare.mp3");
                break;
    
            case "l":
                sound = new Audio("sounds/kick-bass.mp3");
                break;
        }
    sound.play();
    }

    function buttonanimation(key)
    {
        document.querySelector("."+key).classList.add("pressed");
        //pressed is a style class .pressed
        setTimeout(function(){
            document.querySelector("."+key).classList.remove("pressed");
        },100);
    }
    