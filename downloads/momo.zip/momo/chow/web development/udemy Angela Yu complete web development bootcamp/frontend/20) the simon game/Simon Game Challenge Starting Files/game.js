//alert("wassup bald homies");
var colors = ["red", "blue", "green", "yellow"];
var pattern = [];
var userclickedpattern=[];
var randomColor;
var notOut = 1; // Initialize notOut variable

while(notOut===1)
{
addToSequence();
showsequence();

if(!arraysAreEqual(pattern,userclickedpattern))
{
    notOut=0;
}
}

$(".yellow").on("click", function () {
    $(".yellow").fadeOut().fadeIn();
    userclickedpattern.push(".yellow");
});
$(".green").on("click", function () {
    $(".green").fadeOut().fadeIn();
    userclickedpattern.push(".green");
});
$(".blue").on("click", function () {
    $(".blue").fadeOut().fadeIn();
    userclickedpattern.push(".blue");
});
$(".red").on("click", function () {
    $(".red").fadeOut().fadeIn();
    userclickedpattern.push(".red");
});

function addToSequence() {
    randomColor = colors[Math.floor(Math.random() * 4)];
    pattern.push(randomColor);
    console.log(pattern);
}

function showsequence() {
    for (var i = 0; i < pattern.length; i++) {
        (function(index) {
            setTimeout(function() {
                $("." + pattern[index]).fadeOut().fadeIn();
            }, i * 1000); // i * 1000 milliseconds (1 second delay for each iteration)
        })(i);
    }
}

function arraysAreEqual(array1, array2) {
    return JSON.stringify(array1) === JSON.stringify(array2);
}
