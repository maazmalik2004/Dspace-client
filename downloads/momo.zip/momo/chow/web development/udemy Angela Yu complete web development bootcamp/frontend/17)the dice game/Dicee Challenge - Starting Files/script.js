var randnum1=Math.floor((Math.random())*6)+1;
var randnum2=Math.floor((Math.random())*6)+1;

var diceimg1="images/dice"+randnum1+".png";
var diceimg2="images/dice"+randnum2+".png";

document.querySelectorAll("img")[0].setAttribute("src",diceimg1);
document.querySelectorAll("img")[1].setAttribute("src",diceimg2);