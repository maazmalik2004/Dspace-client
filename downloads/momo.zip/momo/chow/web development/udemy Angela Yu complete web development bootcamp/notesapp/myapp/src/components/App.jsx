import React from "react";
import ToDoItem from "./ToDoItem";

function App() {
  const [inputText, setInputText] = React.useState("");
  const [items, setItems] = React.useState([]);

  function handleChange(event) {
    setInputText(event.target.value);
  }

  function addItem() {
    if (inputText.trim() !== "") {
      const newItems = [...items];
      newItems.push(inputText.trim());
      setItems(newItems);
      setInputText("");
    }
  }

  function deleteItem(index) {
    // Use setItems directly with the filter result
    setItems((prevItems) => prevItems.filter((_, i) => i !== index));
  }

  // Handle Enter key press to add item
  function handleKeyPress(event) {
    if (event.key === "Enter") {
      addItem();
    }
  }

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input
          onChange={handleChange}
          onKeyPress={handleKeyPress}
          type="text"
          value={inputText}
          placeholder="Add a new task"
        />
        <button onClick={addItem}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
          {items.map((todoItem, index) => (
            <ToDoItem
              key={index}
              id={index}
              value={todoItem}
              onDoubleClicked={deleteItem}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
