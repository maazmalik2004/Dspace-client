import React from "react";

function ToDoItem(prop) {
  const [clicked, setClicked] = React.useState(false);

  function handleDoubleClick() {
    prop.onDoubleClicked(prop.id);
  }

  return (
    <div>
      <li
        style={{
          textDecoration: clicked ? "line-through" : "none",
          userSelect: "none",
          // Add any other inline styles you want to apply
        }}
        onClick={() => setClicked(!clicked)}
        onDoubleClick={handleDoubleClick}
      >
        {prop.value}
      </li>
    </div>
  );
}

export default ToDoItem;
