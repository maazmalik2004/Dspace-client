import express from "express";
const app = express();
const port = 3000;

app.get("/", (req, res) => {
  res.send("<h1>Hello World</h1>");//sending back a HTML page
  console.log(req.rawHeaders);
});//handle get home page / request

app.get("/about", (req, res) => {
  console.log(req.rawHeaders);
  res.send("<h1>About Me</h1><p>My name is maaz</p>");//sending back a HTML page
});//handle /about request

app.get("/contact", (req, res) => {
  res.send("<h1>Contact Me</h1><p>Phone: +1234567890</p>");//sending back the contact page
});//handle /contact request

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});//listening to port 3000 out of various ports