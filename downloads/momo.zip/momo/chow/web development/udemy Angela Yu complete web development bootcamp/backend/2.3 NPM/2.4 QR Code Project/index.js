import inquirer from "inquirer";
import qr from "qr-image";
import fs from "fs";

inquirer
  .prompt([
    {
      message: "Type in your URL: ",
      name: "URL",
    }//this is an array of JS object containing key value pairs, these are properties of question object that we are passing in the inquirer.prompt(question) function
  ])
  .then((answers) => {
    var url = answers.URL;//we take the input URL from the user
    var qrpng = qr.image(url);//pass that URL into the QR generator function
    qrpng.pipe(fs.createWriteStream("qr_img.png"));//save that generated QR as a image file 

    fs.writeFile("URL.txt", url, (err) => {//save the URL in a text file
      if (err) throw err;
      console.log("The file has been saved!");
    });
  })
  .catch((error) => {
    if (error.isTtyError) {
      
    } else {
    }
  });