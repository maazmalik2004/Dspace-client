import superheroes from 'superheroes';

const mysname = superheroes.random();
console.log(mysname);