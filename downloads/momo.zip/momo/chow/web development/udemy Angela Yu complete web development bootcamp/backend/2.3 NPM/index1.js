//var generateName=require("sillyname");
import generateName from "sillyname"

var sillyname=generateName();

console.log("my sillyname is : "+sillyname);
