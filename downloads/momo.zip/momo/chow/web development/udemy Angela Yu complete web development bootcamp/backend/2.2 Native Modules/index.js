var fs=require("fs");

fs.writeFile("message.txt","hello world !",function(err){
    if(err)
    {
        throw err
    }
    else
    {
        console.log("file created and updated !");
    }
});

fs.readFile("message.txt",function(err,data){
    if(err)
    {
        throw err
    }
    else
    {
        console.log("data inside file : "+data);
    }
});