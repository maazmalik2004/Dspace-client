import express from "express";
const app=express();

const port=3000;

app.get("/",(req,res)=>{

    const dateobj=new Date();
    var day=dateobj.getDay();
    var advice;
    if(day===0 || day==6)
    {
        day="weekend";
        advice="party hard ";
    }
    else
    {
        day="weekday";
        advice="work hard !";
    }

    res.render("index.ejs",
    {
        dayType:day,
        advice:advice
    });
});

app.listen(port,()=>
{
    console.log("server running at port 3000, listening to port 3000");
});

