import express from "express";

import { fileURLToPath } from "url";
import { dirname } from "path";

import bodyParser from "body-parser";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true })); // Use body-parser middleware to parse URL-encoded bodies

function logger(req, res, next) {
  console.log("request type : ", req.method);
  console.log("request URL  : ", req.url);
  next();
} // custom middleware

app.use(logger);

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

app.post("/submit", (req, res) => {
  // Use req.body directly since the body-parser middleware is now used
  var combined = req.body["street"] + req.body["pet"];
  res.send("Your band name is " + combined);
});

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});
