import mongoose from "mongoose";

//defining the schema for the db. we use mongoose for the same as it might contain some metadata as well, not sure
const productSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "please enter product name"],
    },
    quantity: {
      type: Number,
      required: true,
      default: 0,
    },
    price: {
      type: Number,
      required: true,
    },
    image: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);
//timestamps will keep track of when the schema was created

const product = mongoose.model("product",productSchema);//passing the blueprint for building the collection within a database

export default product
//exporting the collections object