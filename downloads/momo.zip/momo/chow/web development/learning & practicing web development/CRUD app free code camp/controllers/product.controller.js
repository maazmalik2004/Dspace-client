import product from "../models/product.model.js";

async function getProducts(req, res) {
    try {
        const myProducts = await product.find({});
        res.status(200).send({
            success: true,
            myProducts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
}

async function getProduct(req, res) {
    try {
        const id = req.params.id;
        const myProduct = await product.findById(id);

        if (!myProduct) {
            return res.status(404).send({
                success: false,
                message: "Product not found"
            });
        }

        res.status(200).send({
            success: true,
            myProduct
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
}

async function createProduct(req, res) {
    try {
        const myProduct = await product.create(req.body);
        
        res.status(200).send({
            success: true,
            message: "Successfully created product",
            product: myProduct
        });
    } catch (error) {
        res.status(500).send({
            success: false,
            message: "Product creation failed, server error",
            error: error.message
        });
    }
}

async function updateProduct(req, res) {
    try {
        const id = req.params.id;
        const myProduct = await product.findByIdAndUpdate(id, req.body, { new: true });

        if (!myProduct) {
            return res.status(404).send({
                success: false,
                message: "Product not found"
            });
        }

        res.status(200).send({
            success: true,
            myProduct
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
}

async function deleteProduct(req, res) {
    try {
        const id = req.params.id;
        const myProduct = await product.findByIdAndDelete(id);

        if (!myProduct) {
            return res.status(404).send({
                success: false,
                message: "Product not found"
            });
        }
        
        res.status(200).send({
            success: true,
            message: "Deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
}

export default {
    getProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct
};
