import express from "express" 
import mongoose from "mongoose" 
import productRoutes from "./routes/product.route.js"

//middleware
const app = express() 
//server does not accept json by default in the request body. it must be passed through a middleware that can parse json as a json object
app.use(express.json());
app.use(express.urlencoded({extended:false}))

mongoose.connect("mongodb://localhost:27017/").then(function(){
    console.log("mongoDb connected successfully")
    //once we connect to the database, we run the server. first we collect the lemons and the sugar, and then we start a lemonade stand
    app.listen(3000, function(){
        console.log('server is running on port 3000')
    }) 
}).catch(function(error){
    console.error("could not connect to mongoDb ",error)
}) 

//routes
app.use("/api/products",productRoutes)